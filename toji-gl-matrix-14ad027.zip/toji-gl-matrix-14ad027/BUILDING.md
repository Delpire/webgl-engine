Building for the browser
========================


To build `gl-matrix.js` and `gl-matrix-min.js` for use in the browser run the following command:

    webpack && webpack --config webpack.config.min.js